export interface NavItemType {
  name: string;
  path: string;
  icon?: React.ComponentType<{ className?: string }>;
}